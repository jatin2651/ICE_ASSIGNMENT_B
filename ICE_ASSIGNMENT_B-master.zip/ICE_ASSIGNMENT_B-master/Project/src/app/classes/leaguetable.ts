export class Leaguetable {

constructor(public away: string[], public crestURI: string, public draws: number, public goalDifference: number, public home: string[], public losses: number, public playedGames: number, public points: number,public position: number, public teamName: string, public wins:number ){}

}
